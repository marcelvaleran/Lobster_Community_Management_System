How to install:
1. Extract the file on htdocs file
2. Open PhpMyAdmin (localhost/phpmyadmin)
3. Create a new database with name, "database"
4. Import the SQL file from database file
5. Open the link, < localhost/Lobster_Community_Management_System
6. Admin account
   - email: admin8@gmail.com
   - pass: 123